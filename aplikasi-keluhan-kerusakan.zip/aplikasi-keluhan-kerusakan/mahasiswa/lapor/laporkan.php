<?php

require '../../Template/init.php';
require '../../backend/init.php';

Header::head('Laporkan Keluhan!');

?>



<div class="container-fluid">
	
	<div class="row justify-content-center">
		<div class="col-md-5 bg-light">
			<div class="text-center display-4">Isi Data Laporan Anda!</div>
			<form method="POST" action="<?=$_SESSION['url']?>backend/laporkan.php" enctype="multipart/form-data" class="m-3 mt-5" autocomplete="off" >

				<div class="form-group mb-4">
					<label>Nama Anda?</label>
					<input name="nama" class="form-control" required="on">
				</div>

			<div class="custom-file mb-3">
			  <input name="profile" type="file" class="custom-file-input" required="on">
			  <label class="custom-file-label">Foto Anda?</label>
			</div>

			<div class="custom-file mb-3">
			  <input name="lokasi" type="file" class="custom-file-input" required="on">
			  <label class="custom-file-label">Foto Lokasi?</label>
			</div>

				<div class="form-group">
					<label>Keluhan Anda?</label>
					<input name="keluhan" class="form-control" required="on">
				</div>

				<div class="form-group mb-5">
					<label>Fasilitas?</label>
					<input name="fasilitas" class="form-control" required="on">
				</div>


				<div class="input-group">
				  <div class="input-group-prepend">
				    <span class="input-group-text">Keterangan?</span>
				  </div>
				  <textarea name="keterangan" class="form-control" aria-label="With textarea" style="height: 200px;" required="on"></textarea>
				</div>

				<button name="lapor" class="btn btn-success float-right m-3">Kirim</button>
				<button type="reset" class="btn btn-danger float-right m-3">Bersihkan</button>
			</form>
			
		</div>
	</div>
</div>











<?php

Dashboard::dashFootPetugas();

Footer::foot();

?>