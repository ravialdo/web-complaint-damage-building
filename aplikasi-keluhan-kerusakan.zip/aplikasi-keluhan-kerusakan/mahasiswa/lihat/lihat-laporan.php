<?php

require '../../Template/init.php';
require '../../backend/init.php';

Header::head('Lihat Laporan!');

?>

<div class="display-4 m-3 text-center" style="font-size: 30px;">Data Yang Di Laporkan!</div>

<?php

if( $queryLihatData->num_rows > 0 ){

?>

<div class="container">
<table class="table table-striped table-responsive-sm">
  <thead class="table-primary">
    <tr>
      <th scope="col">No</th>
      <th scope="col">Nama Pelapor</th>
      <th scope="col">Keluhan</th>
      <th scope="col">Fasilitas</th>
      <th scope="col">Tanggal Lapor</th>
      <th scope="col">Keterangan</th>
    </tr>
  </thead>

<?php

	$i = 1;

	while( $row = $queryLihatData->fetch_assoc() ){

?>

  <tbody>
    <tr>
      <th scope="row"><?=$i?></th>
      <td><?=$row['nama_mahasiswa']?></td>
      <td><?=$row['nama_keluhan']?></td>
      <td><?=$row['fasilitas']?></td>
      <td><?=$row['tanggal_lapor']?></td>
      <td><?=$row['keterangan']?></td>
    </tr>
    
 

<?php
		}
	}else{

      echo '<div class="alert alert-warning mt-4 text-center alert-dismissible fade show" role="alert">
        Tidak ada yang <strong> Melaporkan Keluhan!</strong> 
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
             <span aria-hidden="true">&times;</span>
         </button>
     </div>';
  }
?>

	</tbody>
</table>


<div class="display-4 m-3 mt-5 text-center" style="font-size: 30px;">Data Yang Di Kerjakan!</div>

<?php

if( $queryLihatDataDikerjakan->num_rows > 0 ){

?>

<div class="container">
<table class="table table-striped table-responsive-sm">
  <thead class="table-primary">
    <tr>
      <th scope="col">No</th>
      <th scope="col">Nama Pelapor</th>
      <th scope="col">Keluhan</th>
      <th scope="col">Fasilitas</th>
      <th scope="col">Tanggal Mulai</th>
      <th scope="col">Keterangan</th>
    </tr>
  </thead>

<?php

  $i = 1;

  while( $row = $queryLihatDataDikerjakan->fetch_assoc() ){

?>

  <tbody>
    <tr>
      <th scope="row"><?=$i?></th>
      <td><?=$row['nama_mahasiswa']?></td>
      <td><?=$row['nama_keluhan']?></td>
      <td><?=$row['fasilitas']?></td>
      <td><?=$row['tanggal_mulai']?></td>
      <td><?=$row['keterangan']?></td>
    </tr>
    
 

<?php
    }
  }else{

      echo '<div class="alert alert-warning mt-4 text-center alert-dismissible fade show" role="alert">
        Tidak ada <strong> Keluhan yang Sedang Dikerjakan!</strong> 
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
             <span aria-hidden="true">&times;</span>
         </button>
     </div>';
  }
?>

  </tbody>
</table>


<a class="btn btn-primary float-right mr-5" href="<?=$_SESSION['url']?>" role="button">Kembali</a>
</div>

<?php

Dashboard::dashFootPetugas();

Footer::foot();

?>