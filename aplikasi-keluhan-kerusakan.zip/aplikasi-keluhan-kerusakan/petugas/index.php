<?php

require '../Template/init.php';
require '../backend/init.php';

Header::head('Hello Petugas!');

Dashboard::dashHeadPetugas('Home');

?>

<div class="row justify-content-center">
	<div class="col text-center mt-5">
		
		<div class="display-4" style="font-size: 50px;"> Selamat Datang, <?=$_SESSION['nama']?>!</div>
		<div class="display-4 mt-1 mb-5" style="font-size: 30px;"> Semoga hari - hari anda menyenangkan.</div>

	</div>
</div>




<?php

Dashboard::dashFootPetugas();

Footer::foot();

?>