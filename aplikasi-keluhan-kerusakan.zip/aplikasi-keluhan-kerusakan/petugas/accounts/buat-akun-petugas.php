<?php

require '../../Template/init.php';
require '../../backend/init.php';

Header::head('Buat Akun Petugas!');

Dashboard::dashHeadPetugas('Buat Akun Petugas!');

?>


<div class="row justify-content-center" style="margin-left: 0rem; margin-right: 0rem; margin-bottom: 2rem;">
	<div class="col-md-4">
		

		<form method="POST" enctype="multipart/form-data" action="<?=$_SESSION['url']?>backend/validasi-daftar-Petugas.php" style="margin-top: 20%;" autocomplete="off">

			<div class="text-center display-4 ml-1 mr-1 mb-2" style="font-size: 50px;">Silahkan isi data di bawah ini!</div>

			<div class="custom-file mb-3">
			  <input name="gambar" type="file" class="custom-file-input">
			  <label class="custom-file-label">Foto Profile?</label>
			</div>

		
		  <div class="form-group">
		    <input name="nama" type="text" class="form-control" placeholder="Nama?" pattern="[a-z A-Z]+" minlength="6" maxlength="20" required>
		    
		  </div>
		  <div class="form-group">
		    
		    <input name="username" type="text" class="form-control" minlength="7" minlength="20" placeholder="Username?" required>
		  </div>
		  <div class="form-group">
		    
		    <input name="password" type="text" class="form-control" minlength="7" minlength="20" placeholder="Password?" required>
		  </div>
		  
		  <button name="daftarPetugas" type="submit" class="btn btn-success float-right">Daftar</button>
		 	<a class="text-muted" href="<?=$_SESSION['url']?>index.php">Sudah punya akun?</a>
		</form>
	</div>

</div>



<?php

Dashboard::dashFootPetugas();

Footer::foot();

?>
