<?php

require '../../Template/init.php';
require '../../backend/init.php';

Header::head('Belum Dikerjakan!');

Dashboard::dashHeadPetugas('Belum Dikerjakan');

$JAN = Grafik::perbulan('JAN');
$FEB = Grafik::perbulan('FEB');
$MAR = Grafik::perbulan('MAR');
$APR = Grafik::perbulan('APR');
$MAY = Grafik::perbulan('MAY');
$JUN = Grafik::perbulan('JUN');
$JUL = Grafik::perbulan('JUL');
$AUG = Grafik::perbulan('AUG');
$SEP = Grafik::perbulan('SEP');
$OCT = Grafik::perbulan('OCT');
$NOV = Grafik::perbulan('NOV');
$DEC = Grafik::perbulan('DEC');



?>

<div class="container">
	<div class="display-4 text-center my-3">Grafik Kerusakan Perbulan</div>
<div class="h1 mt-2" style="transform: rotate(1deg);">January <?=Get::tahun();?></div>
<div class="progress my-3">
  <div class="progress-bar progress-bar-striped" role="progressbar" style="width:<?=$JAN?>%" aria-valuenow="3" aria-valuemin="0" aria-valuemax="100"> <?=$JAN?>%</div>
</div>

<div class="h1 mt-2" style="transform: rotate(1deg);">February <?=Get::tahun();?></div>
<div class="progress my-3">
  <div class="progress-bar progress-bar-striped bg-success" role="progressbar" style="width: <?=$FEB?>%" aria-valuenow="<?=$FEB?>" aria-valuemin="0" aria-valuemax="100"><?=$FEB?>%</div>
</div>

<div class="h1 mt-2" style="transform: rotate(1deg);">Maret <?=Get::tahun();?></div>
<div class="progress my-3">
  <div class="progress-bar progress-bar-striped bg-info" role="progressbar" style="width: <?=$MAR?>%" aria-valuenow="<?=$MAR?>" aria-valuemin="0" aria-valuemax="100"><?=$MAR?>%</div>
</div>

<div class="h1 mt-2" style="transform: rotate(1deg);">April <?=Get::tahun();?></div>
<div class="progress my-3">
  <div class="progress-bar progress-bar-striped bg-warning" role="progressbar" style="width: <?=$APR?>%" aria-valuenow="<?=$APR?>" aria-valuemin="0" aria-valuemax="100"><?=$APR?>%</div>
</div>

<div class="h1 mt-2" style="transform: rotate(1deg);">Mei <?=Get::tahun();?></div>
<div class="progress my-3">
  <div class="progress-bar progress-bar-striped bg-danger" role="progressbar" style="width: <?=$MAY?>%" aria-valuenow="<?=$MAY?>%" aria-valuemin="0" aria-valuemax="100"><?=$MAY?>%</div>
</div>

<div class="h1 mt-2" style="transform: rotate(1deg);">Juni <?=Get::tahun();?></div>
<div class="progress my-3">
  <div class="progress-bar progress-bar-striped bg-info" role="progressbar" style="width: <?=$JUN?>%" aria-valuenow="<?=$JUN?>" aria-valuemin="0" aria-valuemax="100"><?=$JUN?>%</div>
</div>

<div class="h1 mt-2" style="transform: rotate(1deg);">Juli <?=Get::tahun();?></div>
<div class="progress my-3">
  <div class="progress-bar progress-bar-striped bg-warning" role="progressbar" style="width: <?=$JUL?>%" aria-valuenow="<?=$JUL?>" aria-valuemin="0" aria-valuemax="100"><?=$JUL?>%</div>
</div>

<div class="h1 mt-2" style="transform: rotate(1deg);">Agustus <?=Get::tahun();?></div>
<div class="progress my-3">
  <div class="progress-bar progress-bar-striped bg-success" role="progressbar" style="width: <?=$AUG?>%" aria-valuenow="<?=$SEP?>" aria-valuemin="0" aria-valuemax="100"><?=$SEP?>%</div>
</div>

<div class="h1 mt-2" style="transform: rotate(1deg);">September <?=Get::tahun();?></div>
<div class="progress my-3">
  <div class="progress-bar progress-bar-striped bg-info" role="progressbar" style="width: <?=$SEP?>%" aria-valuenow="<?=$SEP?>" aria-valuemin="0" aria-valuemax="100"><?=$SEP?>%</div>
</div>

<div class="h1 mt-2" style="transform: rotate(1deg);">Oktober <?=Get::tahun();?></div>
<div class="progress my-3">
  <div class="progress-bar progress-bar-striped bg-success" role="progressbar" style="width: <?=$OCT?>%" aria-valuenow="<?=$OCT?>" aria-valuemin="0" aria-valuemax="100"><?=$OCT?>%</div>
</div>

<div class="h1 mt-2" style="transform: rotate(1deg);">November <?=Get::tahun();?></div>
<div class="progress my-3">
  <div class="progress-bar progress-bar-striped bg-warning" role="progressbar" style="width: <?=$NOV?>%" aria-valuenow="<?=$NOV?>" aria-valuemin="0" aria-valuemax="100"><?=$NOV?>%</div>
</div>

<div class="h1 mt-2" style="transform: rotate(1deg);">Desember <?=Get::tahun();?></div>
<div class="progress my-3">
  <div class="progress-bar progress-bar-striped bg-danger" role="progressbar" style="width: <?=$DEC?>%" aria-valuenow="<?=$DEC?>" aria-valuemin="0" aria-valuemax="100"><?=$DEC?>%</div>
</div>
</div>

<?php

Dashboard::dashFootPetugas();

Footer::foot();

?>