<?php

require '../../Template/init.php';
require '../../backend/init.php';

Header::head('Table Keluhan Masuk!');

Dashboard::dashHeadPetugas('Data Keluhan Masuk!');

?>

<div class="container-fluid">
	<div class="row">
		<div class="col-md-12">		
		
<?php

if( $queryLihatKeluhanMasuk->num_rows > 0 ){

?>

<table class="table table-responsive-sm table-striped mt-3">
		  <thead class="table-dark">
		    <tr>
		      <th scope="col">No</th>
		      <th scope="col">Nama Mahasiswa</th>
		      <th scope="col">Keluhan</th>
		      <th scope="col">Fasilitas</th>
		      <th scope="col">Tanggal Lapor</th>
		      <th scope="col">Aksi</th>
		    </tr>
		  </thead>


<?php

	$i = 1;

	while( $row = $queryLihatKeluhanMasuk->fetch_assoc() ){

?>

		
		  <tbody>
		    <tr>
		      <th scope="row"><?=$i?></th>
		      <td><?=$row['nama_mahasiswa']?></td>
		      <td><?=$row['nama_keluhan']?></td>
		      <td><?=$row['fasilitas']?></td>
		      <td><?=$row['tanggal_lapor']?></td>
		      <td>
		      	<a href="<?=$_SESSION['url']?>backend/delete-table-klh.php?klh=<?=$row['id']?>" class="btn btn-danger" role="button"> Hapus</a>
		      </td>

		    </tr>


<?php
		$i++;

	}

}  else {

	echo '<div class="alert alert-warning mt-4 text-center alert-dismissible fade show" role="alert">
  			Data <strong>Laporan!</strong> Masuk tidak ada.
  				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
   					 <span aria-hidden="true">&times;</span>
 				 </button>
		 </div>';
}

?>

				</tbody>
			</table>
		</div>
	</div>
</div>

<?php

Dashboard::dashFootPetugas();

Footer::foot();

?>