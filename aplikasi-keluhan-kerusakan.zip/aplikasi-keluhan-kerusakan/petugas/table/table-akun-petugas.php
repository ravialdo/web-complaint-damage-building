<?php

require '../../Template/init.php';
require '../../backend/init.php';

Header::head('Table Akun Petugas!');

Dashboard::dashHeadPetugas('Data Akun petugas!');

?>

<div class="container-fluid">
	<div class="row">
		<div class="col-md-12">		
		
<?php

if( $queryLihatAkunPetugas->num_rows > 0 ){

?>

<table class="table table-responsive-sm table-striped mt-3">
		  <thead class="table-dark">
		    <tr>
		      <th scope="col">No</th>
		      <th scope="col">Nama Mahasiswa</th>
		      <th scope="col">Username</th>
		      <th scope="col">Password</th>
		      <th scope="col">Aksi</th>
		    </tr>
		  </thead>


<?php

	$i = 1;

	while( $row = $queryLihatAkunPetugas->fetch_assoc() ){

?>

		
		  <tbody>
		    <tr>
		      <th scope="row"><?=$i?></th>
		      <td><?=$row['nama']?></td>
		      <td><?=$row['username']?></td>
		      <td><?=base64_decode($row['password'])?></td>
		      <td>
		      	<a href="<?=$_SESSION['url']?>backend/delete-table-akn.php?akn=<?=$row['id']?>" class="btn btn-danger" role="button"> Hapus</a>
		      </td>

		    </tr>


<?php
		$i++;

	}

}  else {

	echo '<div class="alert alert-warning mt-4 text-center alert-dismissible fade show" role="alert">
  			Data <strong>Laporan!</strong> Masuk tidak ada.
  				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
   					 <span aria-hidden="true">&times;</span>
 				 </button>
		 </div>';
}

?>

				</tbody>
			</table>
		</div>
	</div>
</div>

<?php

Dashboard::dashFootPetugas();

Footer::foot();

?>