<?php

require '../../Template/init.php';
require '../../backend/init.php';

Header::head('Table Daftar Permintaan Perbaikan!');

Dashboard::dashHeadPetugas('Data Daftar Permintaan Perbaikan!');

?>

<div class="container-fluid">
	<div class="row">
		<div class="col-md-12">		
		
<?php

if( $queryLihatDPP->num_rows > 0 ){

?>

<table class="table table-striped table-responsive mt-3">
		  <thead class="table-dark">
		  
		    <tr>
		      <th scope="col">No</th>
		      <th scope="col">Pelapor</th>
		      <th scope="col">Nama Perbaikan</th>
		      <th scope="col">Fasilitas</th>
		      <th scope="col">Dikerjakan</th>
		      <th scope="col">Tanggal</th>
		      <th scope="col">Nama Teknisi</th>
		      <th scope="col">Tanggal Lapor</th>
		      <th scope="col">Tanggal Selesai</th>
		      <th scope="col">Estimasi</th>
		      <th scope="col">Tandatangan Pelapor</th>
		      <th scope="col">Keterangan</th>
		      <th scope="col">Aksi</th>
		      
		    </tr>
		  </thead>


<?php

	$i = 1;

	while( $row = $queryLihatDPP->fetch_assoc() ){

?>

		
		  <tbody>
		    <tr>
		      <th scope="row"><?=$i?></th>
		      <td><?=$row['pelapor']?></td>
		      <td><?=$row['nama_perbaikan']?></td>
		      <td><?=$row['fasilitas']?></td>
		      <td><?=$row['dikerjakan']?></td>
		     <td><?=$row['tanggal']?></td>
		      <td><?=$row['nama_teknisi']?></td>
		      <td><?=$row['tanggal_lapor']?></td>
		      <td><?=$row['tanggal_selesai']?></td>
		      <td><?=$row['estimasi']?></td>
		      <td><img src="<?=$_SESSION['url']?>assets/img/<?=$row['tanda_pelapor']?>" class="rounded img-thumbnail" style="width: 5rem;"></td>
		      <td><?=$row['keterangan']?></td>
		      <td>
		      	<a href="<?=$_SESSION['url']?>backend/delete-table-idx.php?idx=<?=$row['id']?>" class="btn btn-danger" role="button"> Hapus</a>
		      </td>

		    </tr>


<?php
		$i++;

	}

}  else {

	echo '<div class="alert alert-warning mt-4 ml-4 mr-4 text-center alert-dismissible fade show" role="alert">
  			Data <strong>Daftar Permintaan Perbaikan!</strong> tidak ada.
  				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
   					 <span aria-hidden="true">&times;</span>
 				 </button>
		 </div>';
}

?>

				</tbody>
			</table>
		</div>
	</div>
</div>

<?php

Dashboard::dashFootPetugas();

Footer::foot();

?>