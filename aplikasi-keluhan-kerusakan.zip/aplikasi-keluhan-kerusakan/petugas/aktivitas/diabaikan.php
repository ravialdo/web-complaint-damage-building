<?php

require '../../Template/init.php';
require '../../backend/init.php';

Header::head('Daftar diabaikan!');

Dashboard::dashHeadPetugas('Daftar diabaikan!');

?>

	<div class="row justify-content-center">


<?php

if( $queryDiabaikan->num_rows > 0 ){


	while( $row = $queryDiabaikan->fetch_assoc() ){
           
 ?>

		<div class="col-md-4">

			<div class="card m-3 shadow">
				  <img class="card-img-top img-thumbnail img-responsive" src="<?=$_SESSION['url']?>assets/img/<?=$row['tanda_pelapor']?>" alt="profile mahasiswa">
				  <div class="card-body">
				    <h5 class="card-title">Keluhan</h5>

				    <?php $_SESSION['id'] = $row['id'] ?>

				    
				    <a href="http://localhost/aplikasi-keluhan-kerusakan/backend/persiapan-diabaikan.php?index=<?=$row['id']?>" class="btn btn-success float-right" role="button" style="margin-top: -2.50rem;"> Kerjakan!</a>

				    <p class="card-text"><?=$row['nama_keluhan']?></p>

				    <?php $lokasi = $row['foto_lokasi']; ?>

				    <div class="row">

					<div class="col-12">

				    <nav class="navbar navbar-expand-xs navbar-light navbar-dashboard">

					 	<a class="navbar-brand" href="#"> Foto Lokasi </a>
					 <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#slideGambar<?=$row['id']?>" aria-controls="slideGambar<?=$row['id']?>" aria-expanded="false" aria-label="Toggle navigation">
					    <span class="fas fa-angle-down"></span>
					 </button>
						 <div class="collapse navbar-collapse" id="slideGambar<?=$row['id']?>">
					    	<div class="navbar-nav">
					   	   		<a class="nav-item nav-link" href="'.$_SESSION['url'].'petugas/accounts/buat-akun-petugas.php"> <img src="<?=$_SESSION['url']?>assets/img/<?=$lokasi?>" class="img-fluid rounded img-thumbnail"> <span class="sr-only">(current)</span></a>
					 	   </div>
						 </div>
					
					</nav>
						</div> 
					</div>
					
				  </div>

				   <ul class="list-group list-group-flush">
				    <li class="list-group-item"> Nama <?=$row['nama_mahasiswa']?> </li>
				    <li class="list-group-item"> Tanggal lapor <?=$row['tanggal_lapor']?> </li>
				    <li class="list-group-item"> Fasilitas <?=$row['fasilitas']?> </li>
				    <li class="list-group-item"> Keterangan <?=$row['keterangan']?> </li>
				  </ul>
				  
				  <div class="card-body">
				    <a href="http://localhost/aplikasi-keluhan-kerusakan/backend/delete-diabaikan.php?delete=<?=$row['id']?>" class="card-link btn btn-danger float-right" role="button">Hapus</a>
				  </div>
			</div>



		</div>		

<?php

	}

} else {

	echo '<div class="alert alert-warning mt-4 ml-4 mr-4 text-center alert-dismissible fade show" role="alert">
  			Data <strong>Laporan!</strong> Diabaikan tidak ada.
  				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
   					 <span aria-hidden="true">&times;</span>
 				 </button>
		 </div>';
}

?>

	</div>


<?php

Dashboard::dashFootPetugas();

Footer::foot();

?>