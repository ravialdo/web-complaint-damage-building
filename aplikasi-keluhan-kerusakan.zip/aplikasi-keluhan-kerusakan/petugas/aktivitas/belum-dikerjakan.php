<?php

require '../../Template/init.php';
require '../../backend/init.php';

Header::head('Belum Dikerjakan!');

Dashboard::dashHeadPetugas('Belum Dikerjakan');

?>

	<div class="container">

		<div class="row justify-content-center">
			<div class="col-md-6">

				<form class="m-4" method="POST">
				  <div class="form-row">
				    <div class="col">
				      <input name="cari" type="text" class="form-control" placeholder="Cari Keluhan..">
				      <div class="text-muted text-center" style="font-size: .80rem;">cari data keluhan berdasarkan nama keluhan</div>
				    </div>
				    <button class="btn bg-transparent" type="submit">
				    	<i class="fas text-dark fa-search fa-2x mb-3"></i>
				    </button>
				    
				  </div>
				</form>
				
			</div>
		</div>
	</div>

<?php

if( isset($_POST['cari']) && $_POST['cari'] != null && $_POST['cari'] != ''  ){

	$cari = $_POST['cari'];

	

		$sql = "SELECT * FROM data_keluhan WHERE nama_keluhan LIKE '%".$cari."%' AND status_perbaikan LIKE 'false'";

		$query = $conn->query($sql);

		echo "<div class='h5 m-4'> <b>Keyword</b> '<i>".$_POST['cari']."</i>'</div>";

		if ($query == true) {
			
?>

<div class="row justify-content-center">


<?php


if( $query->num_rows > 0 ){

		$i = 0;

	while( $row = $query->fetch_assoc() ){

		
           
 ?>

		<div class="col-md-4">

			<div class="card m-3 shadow">

					<?php 
						$tanggal = $row['tanggal_lapor'];
						$waktu   = $row['waktu'];
					 ?>

					 <div class="text-muted ml-auto mr-1"><?=Time::timeAgo(strtotime($tanggal.' '.$waktu));?></div>

				  <img class="card-img-top img-thumbnail img-responsive" src="<?=$_SESSION['url']?>assets/img/<?=$row['tanda_pelapor']?>" alt="profile mahasiswa">
				  <div class="card-body">
				    <h5 class="card-title">Keluhan</h5>

				    <?php $_SESSION['id'] = $row['id'] ?>


				    
				    <a href="http://localhost/aplikasi-keluhan-kerusakan/backend/persiapan.php?index=<?=$row['id']?>" class="btn btn-success float-right" role="button" style="margin-top: -2.50rem;"> Kerjakan!</a>

				    <p class="card-text"><?=$row['nama_keluhan']?></p>

				    <?php $lokasi = $row['foto_lokasi']; ?>

				<div class="row">

					<div class="col-12">

				    <nav class="navbar navbar-expand-xs navbar-light navbar-dashboard">

					 	<a class="navbar-brand" href="#"> Foto Lokasi </a>
					 <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#slideGambar<?=$i?>" aria-controls="slideGambar<?=$i?>" aria-expanded="false" aria-label="Toggle navigation">
					    <span class="fas fa-angle-down"></span>
					 </button>
						 <div class="collapse navbar-collapse" id="slideGambar<?=$i?>">
					    	<div class="navbar-nav">
					   	   		<a class="nav-item nav-link" href="'.$_SESSION['url'].'petugas/accounts/buat-akun-petugas.php"> <img src="<?=$_SESSION['url']?>assets/img/<?=$lokasi?>" class="img-fluid rounded img-thumbnail"> <span class="sr-only">(current)</span></a>
					 	   </div>
						 </div>
					
					</nav>
						</div> 
					</div>

				  </div>

				   <ul class="list-group list-group-flush">
				    <li class="list-group-item"> Nama <?=$row['nama_mahasiswa']?> </li>
				    <li class="list-group-item"> Tanggal lapor <?=$tanggal?> </li>
				    <li class="list-group-item"> Fasilitas <?=$row['fasilitas']?> </li>
				    <li class="list-group-item"> Keterangan <?=$row['keterangan']?> </li>
				  </ul>
				  
				  <div class="card-body">
				    <a href="http://localhost/aplikasi-keluhan-kerusakan/backend/hapus-keluhan.php?delete=<?=$row['id']?>" class="card-link btn btn-danger float-right" role="button">Hapus</a>

				    <a href="<?=$_SESSION['url']?>backend/pekerjaan-diabaikan.php?later=<?=$row['id']?>" class="card-link btn btn-warning float-right mr-2" role="button">Abaikan</a>
				    
				  </div>
			</div>



		</div>		

<?php
	
	$i++;
	
	}

}else{

		echo '<div class="text-center h5 text-italic">Tidak Ditemukan</div>';
	}

		}

	

	}else{


?>		
		
	<br>
	<div class="row justify-content-center">


<?php


if( $belumDikerjakan->num_rows > 0 ){

		$i = 0;

	while( $row = $belumDikerjakan->fetch_assoc() ){

		
           
 ?>

		<div class="col-md-4">

			<div class="card m-3 shadow">

					<?php 
						$tanggal = $row['tanggal_lapor'];
						$waktu   = $row['waktu'];
					 ?>

					 <div class="text-muted ml-auto mr-1"><?=Time::timeAgo(strtotime($tanggal.' '.$waktu));?></div>

			
				  <img class="card-img-top img-thumbnail img-responsive" src="<?=$_SESSION['url']?>assets/img/<?=$row['tanda_pelapor']?>" alt="profile mahasiswa">
				  <div class="card-body">
			


				    <h5 class="card-title">Keluhan</h5>

				    <?php $_SESSION['id'] = $row['id'] ?>


				    
				    <a href="http://localhost/aplikasi-keluhan-kerusakan/backend/persiapan.php?index=<?=$row['id']?>" class="btn btn-success float-right" role="button" style="margin-top: -2.50rem;"> Kerjakan!</a>

				    <p class="card-text"><?=$row['nama_keluhan']?></p>

				    <?php $lokasi = $row['foto_lokasi']; ?>

				<div class="row">

					<div class="col-12">

				    <nav class="navbar navbar-expand-xs navbar-light navbar-dashboard">

					 	<a class="navbar-brand" href="#"> Foto Lokasi </a>
					 <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#slideGambar<?=$i?>" aria-controls="slideGambar<?=$i?>" aria-expanded="false" aria-label="Toggle navigation">
					    <span class="fas fa-angle-down"></span>
					 </button>
						 <div class="collapse navbar-collapse" id="slideGambar<?=$i?>">
					    	<div class="navbar-nav">
					   	   		<a class="nav-item nav-link" href="'.$_SESSION['url'].'petugas/accounts/buat-akun-petugas.php"> <img src="<?=$_SESSION['url']?>assets/img/<?=$lokasi?>" class="img-fluid rounded img-thumbnail"> <span class="sr-only">(current)</span></a>
					 	   </div>
						 </div>
					
					</nav>
						</div> 
					</div>

				  </div>

				   <ul class="list-group list-group-flush">
				    <li class="list-group-item"> Nama <?=$row['nama_mahasiswa']?> </li>
				    <li class="list-group-item"> Tanggal lapor <?=$tanggal?> </li>
				    <li class="list-group-item"> Fasilitas <?=$row['fasilitas']?> </li>
				    <li class="list-group-item"> Keterangan <?=$row['keterangan']?> </li>
				  </ul>
				  
				  <div class="card-body">
				    <a href="http://localhost/aplikasi-keluhan-kerusakan/backend/hapus-keluhan.php?delete=<?=$row['id']?>" class="card-link btn btn-danger float-right" role="button">Hapus</a>

				    <a href="<?=$_SESSION['url']?>backend/pekerjaan-diabaikan.php?later=<?=$row['id']?>" class="card-link btn btn-warning float-right mr-2" role="button">Abaikan</a>
				    
				  </div>
			</div>



		</div>		

<?php
	
	$i++;
	
	}

} else {

	echo '<div class="alert alert-warning mt-4 ml-4 mr-4 text-center alert-dismissible fade show" role="alert">
  			Data <strong>Laporan!</strong> belum Dikerjakan tidak ada.
  				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
   					 <span aria-hidden="true">&times;</span>
 				 </button>
		 </div>';
}

}
?>

	</div>

<?php

Dashboard::dashFootPetugas();

Footer::foot();

?>