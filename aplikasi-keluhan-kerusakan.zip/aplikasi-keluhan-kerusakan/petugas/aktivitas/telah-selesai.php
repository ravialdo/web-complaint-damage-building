<?php

require '../../Template/init.php';
require '../../backend/init.php';

Header::head('Telah Selesai!');

Dashboard::dashHeadPetugas('telah selesai!');

?>


<div class="row justify-content-center">


<?php 

if( $telahSelesai->num_rows > 0 ){

	$i = 0;

	while( $row = $telahSelesai->fetch_assoc() ){
           
 ?>

		<div class="col-md-4">

			<div class="card m-3 shadow">

				<?php 
						$tanggal = $row['tanggal_selesai'];
						$waktu   = $row['waktu_selesai'];
					 ?>

					 <div class="text-muted ml-auto mr-1">selesai <?=Time::timeAgo(strtotime($tanggal.' '.$waktu));?></div>

				  <img class="card-img-top img-thumbnail img-responsive" src="<?=$_SESSION['url']?>assets/img/<?=$row['tanda_pelapor']?>" alt="profile mahasiswa">
				  <div class="card-body">
				    <h5 class="card-title">Keluhan</h5>
				    <p class="card-text"><?=$row['nama_keluhan']?></p>

				    <?php $lokasi = $row['foto_lokasi']; ?>

				     <div class="row">

					<div class="col-12">

				    <nav class="navbar navbar-expand-xs navbar-light navbar-dashboard">

					 	<a class="navbar-brand" href="#"> Foto Lokasi </a>
					 <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#slideGambar" aria-controls="slideGambar" aria-expanded="false" aria-label="Toggle navigation">
					    <span class="fas fa-angle-down"></span>
					 </button>
						 <div class="collapse navbar-collapse" id="slideGambar">
					    	<div class="navbar-nav">
					   	   		<a class="nav-item nav-link" href="'.$_SESSION['url'].'petugas/accounts/buat-akun-petugas.php"> <img src="<?=$_SESSION['url']?>assets/img/<?=$lokasi?>" class="img-fluid rounded img-thumbnail"> <span class="sr-only">(current)</span></a>
					 	   </div>
						 </div>
					
					</nav>
						</div> 
					</div>
					
				  </div>

				   <ul class="list-group list-group-flush">
				    <li class="list-group-item"> Nama <?=$row['nama_mahasiswa']?> </li>
				    <li class="list-group-item"> Waktu Selesai <?=$row['tanggal_selesai']?> </li>
				    <li class="list-group-item"> Fasilitas <?=$row['fasilitas']?> </li>
				    <li class="list-group-item"> Keterangan <?=$row['keterangan']?> </li>
				  </ul>
				  
				  <div class="card-body">
				   
				   <a href="<?=$_SESSION['url']?>backend/rincian.php?detail=<?=$row['id']?>" class="btn btn-info float-right" role="button">Rincian</a>

				   <a href="<?=$_SESSION['url']?>backend/delete.php?index=<?=$row['id']?>" class="btn btn-danger mx-2 float-right" role="button">Hapus</a>

				  </div>
			</div>



		</div>

<?php

		$i++;

	}

	

}else {

	echo '<div class="alert alert-warning mt-4 alert-dismissible fade show" role="alert">
  			Data <strong>Laporan!</strong> selesai Dikerjakan tidak ada.
  				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
   					 <span aria-hidden="true">&times;</span>
 				 </button>
		 </div>';

}

?>
			
		




	</div>







<?php

Dashboard::dashFootPetugas();

Footer::foot();

?>