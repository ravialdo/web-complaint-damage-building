<?php

require '../../Template/init.php';
require '../../backend/init.php';

Header::head('Sedang Dikerjakan!');

Dashboard::dashHeadPetugas('sedang Dikerjakan!');

?>



<div class="row justify-content-center">


<?php 

if( $sedangDikerjakan->num_rows > 0){

	$i = 0;

	while( $row = $sedangDikerjakan->fetch_assoc() ){
           
 ?>

		<div class="col-md-4">

			<div class="card m-3 shadow">

					<?php 
						$tanggal = $row['tanggal_mulai'];
						$waktu   = $row['waktu_mulai'];
					 ?>

					 <div class="text-muted ml-auto mr-1">dikerjakan <?=Time::timeAgo(strtotime($tanggal.' '.$waktu));?></div>

				  <img class="card-img-top img-thumbnail img-responsive" src="<?=$_SESSION['url']?>assets/img/<?=$row['tanda_pelapor']?>" alt="profile mahasiswa">
				  <div class="card-body">
				    <h5 class="card-title">Keluhan</h5>
				    <p class="card-text"><?=$row['nama_keluhan']?></p>

				    <?php $lokasi = $row['foto_lokasi']; ?>

				    <div class="row">

					<div class="col-12">

				    <nav class="navbar navbar-expand-xs navbar-light navbar-dashboard">

					 	<a class="navbar-brand" href="#"> Foto Lokasi </a>
					 <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#slideGambar<?=$row['id']?>" aria-controls="slideGambar<?=$row['id']?>" aria-expanded="false" aria-label="Toggle navigation">
					    <span class="fas fa-angle-down"></span>
					 </button>
						 <div class="collapse navbar-collapse" id="slideGambar<?=$row['id']?>">
					    	<div class="navbar-nav">
					   	   		<a class="nav-item nav-link" href="'.$_SESSION['url'].'petugas/accounts/buat-akun-petugas.php"> <img src="<?=$_SESSION['url']?>assets/img/<?=$lokasi?>" class="img-fluid rounded img-thumbnail"> <span class="sr-only">(current)</span></a>
					 	   </div>
						 </div>
					
					</nav>
						</div> 
					</div>

				  </div>

				   <ul class="list-group list-group-flush">
				    <li class="list-group-item"> Nama <?=$row['nama_mahasiswa']?> </li>
				    <li class="list-group-item"> Nama Teknisi <?=$row['nama_teknisi']?> </li>
				    <li class="list-group-item"> Estimasi <?=$row['estimasi']?> </li>
				    <li class="list-group-item"> Fasilitas <?=$row['fasilitas']?> </li>
				    <li class="list-group-item"> Keterangan <?=$row['keterangan']?> </li>
				  </ul>
				  
				  <div class="card-body">
				    <a href="<?=$_SESSION['url']?>backend/selesai-dikerjakan.php?finish=<?=$row['id']?>" class="card-link btn btn-success float-right" role="button">Selesai</a>
				    <a href="<?=$_SESSION['url']?>backend/batalkan-pekerjaan.php?cancel=<?=$row['id']?>" class="card-link btn btn-danger float-right mr-2" role="button">Batalkan</a>
				  </div>
			</div>



		</div>

<?php

		$i++;

	}

	

}else {

	echo '<div class="alert alert-warning mt-4 mt-4 ml-4 mr-4 text-center alert-dismissible fade show" role="alert">
  			Data <strong>Laporan!</strong> sedang Dikerjakan tidak ada.
  				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
   					 <span aria-hidden="true">&times;</span>
 				 </button>
		 </div>';

}

?>
			
		




	</div>













<?php

Dashboard::dashFootPetugas();

Footer::foot();

?>