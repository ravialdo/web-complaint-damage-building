<?php 

require '../../../Template/init.php';
require '../../../backend/init.php';

Header::head('Rincian!');

Dashboard::dashHeadPetugas('Rincian!');

if( isset($_GET['dtl']) ){

$id = base64_decode($_GET['dtl']);

	$sqlDetail = "SELECT * FROM data_keluhan WHERE id = $id";

	$queryDetail = $conn->query($sqlDetail);

	$row = 	$queryDetail->fetch_assoc();

?>

<div class="row mt-4 mb-4 justify-content-center">
	<div class="col-md-10">

		<div class="card shadow">
		  <div class="card-header text-center display-4" style="font-size: 30px;">
		    Rincian Data Perbaikan!
		  </div>
		  <div class="card-body">
		  	<div class="row justify-content-center">

		  		<img class="card-img-top img-thumbnail img-responsive mx-auto" src="<?=$_SESSION['url']?>assets/img/<?=$row['tanda_pelapor']?>" alt="profile mahasiswa">
		  		
		  	</div>
		  	
		    <h5 class="card-title text-capitalize text-center display-4 m-1" style="font-size: 20px;"><?=$row['nama_mahasiswa']?></h5>
		    <p class="card-text"><b>Keluhan</b> <?=$row['nama_keluhan']?></p>
		    <p class="card-text"><b>Tanggal Laporan</b> <?=$row['tanggal_lapor']?></p>
		    <p class="card-text"><b>Tanggal Selesai</b> <?=$row['tanggal_selesai']?></p>
		    <p class="card-text"><b>Estimasi</b> <?=$row['estimasi']?></p>
		    <p class="card-text"><b>Keterangan</b> <?=$row['keterangan']?></p>
		    
		    <a href="<?=$_SESSION['url']?>petugas/aktivitas/telah-selesai.php" class="btn btn-primary float-right" role="button">Kembali</a>

		    <a href="<?=$_SESSION['url']?>backend/delete.php?index=<?=$row['id']?>" class="btn btn-danger mx-2 float-right" role="button">Hapus</a>

		  </div>
		  <div class="card-footer text-muted text-center">
		    &copy; <?=date('Y')?>-<?=date('Y')+1?> Telkom University
		  </div>
		</div>
		

	</div>
</div>




<?php


}

Dashboard::dashFootPetugas();

Footer::foot();

?>