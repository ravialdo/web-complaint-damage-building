<?php

require '../../../Template/init.php';
require '../../../backend/init.php';

Header::head('Data Pengerjaan!');

Dashboard::dashHeadPetugas('Data Pengerjaan!');

$nama = $_GET['nm'];
$keluhan = $_GET['klh'];
$delete = $_GET['idx'];

$sqlPengerjaan = "SELECT * FROM data_keluhan WHERE nama_mahasiswa LIKE '$nama' AND nama_keluhan LIKE '$keluhan' AND status_perbaikan LIKE 'new'";


 $queryPengerjaan = $conn->query($sqlPengerjaan);


		$row = $queryPengerjaan->fetch_assoc();


?>


<div class="container mt-3">
	
	<div class="row justify-content-center">
		<div class="col-md-5">

			<h3 class="text-center text-uppercase mb-4">Data Pengerjaan</h3>

			<form class="pb-5" method="POST" action="<?=$_SESSION['url']?>backend/kerjakan-diabaikan.php">
				<div class="form-group">
				    <input name="delete" type="hidden" class="form-control" value="<?=$delete?>">
				  </div>
				<div class="form-group">
				    <input name="id" type="hidden" class="form-control" value="<?=$row['id']?>">
				  </div>
				  <div class="form-group">
				    <input name="namaTeknisi" type="text" class="form-control" placeholder="Nama Teknisi?">
				    <small class="form-text text-muted"> di isi dengan nama yang akan mengerjakan!</small>
				  </div>
				  <div class="form-group">
				    <input name="estimasi" type="text" class="form-control" placeholder="Estimasi?">
				    <small class="form-text text-muted"> perkiraan waktu selesai!</small>
				  </div>
				 <button name="kirimPengerjaanDiabaikan" type="submit" class="btn btn-success float-right">Kirim</button>
				</form>
			
		</div>
	</div>

</div>

<?php

Dashboard::dashFootPetugas();

Footer::foot();

?>