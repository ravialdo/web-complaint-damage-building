<?php

require 'Template/init.php';
require 'backend/init.php';

Header::head('Silahkan Masuk!');

?>

<div class="row justify-content-center" style="margin-left: 1rem; margin-right: 1rem;">
	
	<div class="col-md-4">

		
		<form method="POST" action="<?=$_SESSION['url']?>backend/validasi-login.php" style="margin-top: 30%;" autocomplete="off">

			<div class="text-center display-4 mb-2" style="font-size: 50px;">Silahkan Masuk Sebagai Petugas Dengan Akun Anda!</div>
		  <div class="form-group">
		    <?php 

		    	if( empty($_SESSION['nama']) ){

	               echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
							  <strong>Hai..</strong> Anda harus masuk dulu!
							<button type="button" class="close" data-dismiss="alert" aria-label="Close">
			 			   <span aria-hidden="true">&times;</span>
					  </button>
				</div>';

             }

		    ?>
		    <input name="username" type="text" class="form-control" placeholder="Username?" pattern="[a-z A-Z]+" minlength="6" maxlength="20" autofocus required>
		    
		  </div>
		  <div class="form-group">
		    
		    <input name="password" type="password" class="form-control" minlength="7" minlength="20" placeholder="Password?" required>
		  </div>
		  
		  <button name="login" type="submit" class="btn btn-success float-right"><i class="fas fa-sign-in-alt"></i> Masuk</button>
		 	
		</form>
		
	</div>
</div>




<?php

Footer::foot(); 

?>