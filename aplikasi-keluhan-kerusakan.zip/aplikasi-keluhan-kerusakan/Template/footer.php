<?php

class Footer {

    public static function foot(){

        echo '<script src="'.$_SESSION['url'].'assets/js/jquery-slim.min.js"></script>

              <script src="'.$_SESSION['url'].'assets/js/popper.min.js"></script>

              <script src="'.$_SESSION['url'].'assets/bootstrap/js/bootstrap.min.js"></script>
        
                <body/>
            <html/>';
            
    }
}