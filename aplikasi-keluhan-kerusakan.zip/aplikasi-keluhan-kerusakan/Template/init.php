<?php

require 'header.php';
require 'footer.php';
require 'url.php';
require 'dashboard.php';