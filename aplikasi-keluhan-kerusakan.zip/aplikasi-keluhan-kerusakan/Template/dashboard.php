<?php

class Dashboard {

	public static function dashHeadPetugas($titleNav){

		echo '<div class="container-fluid">
    <div class="row">

        <div class="col-md-3 fixed-top" style="height:-webkit-fill-available;">

        	
        		
        	<h5 class="text-center text-white mt-2">Telkom University</h5>
           	<img src="'.$_SESSION['url'].'assets/img/'.$_SESSION['profile'].'" alt="profile" class="rounded-circle img-thumbnail" style="height: 80px;">
          	<p class="text text-white text-capitalize">Hai '.$_SESSION['nama'].'!</p>
            <hr>



            

			<nav class="navbar navbar-expand-xs navbar-dark navbar-dashboard">
			 	<a class="navbar-brand" href="#"><i class="fas fa-clipboard-list"></i> Aktivitas </a>
			 <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar1" aria-controls="navbar1" aria-expanded="false" aria-label="Toggle navigation">
			    <span class="fas fa-angle-down"></span>
			 </button>
				 <div class="collapse navbar-collapse" id="navbar1">
			    	<div class="navbar-nav">
			    		<a class="nav-item nav-link" href="'.$_SESSION['url'].'petugas/aktivitas/belum-dikerjakan.php"> <i class="far fa-sticky-note"></i>  Belum Dikerjakan</a>
			   	   		<a class="nav-item nav-link" href="'.$_SESSION['url'].'petugas/aktivitas/sedang-dikerjakan.php"> <i class="fas fa-people-carry"></i> Sedang Dikerjakan</a>
			   	   		<a class="nav-item nav-link" href="'.$_SESSION['url'].'petugas/aktivitas/telah-selesai.php"> <i class="fas fa-clipboard-check"></i> Telah Selesai</a>
			   	   		<a class="nav-item nav-link" href="'.$_SESSION['url'].'petugas/aktivitas/diabaikan.php"> <i class="fas fa-thumbtack"></i> Daftar diabaikan <span class="badge badge-warning">'.$_SESSION['totalDiabaikan'].'</span></a>
			 	   </div>
				 </div>
			</nav>


			
			<nav class="navbar navbar-expand-xs navbar-dark navbar-dashboard">
			 	<a class="navbar-brand" href="#"><i class="fas fa-table"></i> Tables </a>
			 <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar3" aria-controls="navbar3" aria-expanded="false" aria-label="Toggle navigation">
			    <span class="fas fa-angle-down"></span>
			 </button>
				 <div class="collapse navbar-collapse" id="navbar3">
			    	<div class="navbar-nav">
			   	   		<a class="nav-item nav-link" href="'.$_SESSION['url'].'petugas/table/table-keluhan-masuk.php"> <i class="far fa-envelope-open"></i> Table Keluhan Masuk<span class="sr-only">(current)</span></a>
			  	    	<a class="nav-item nav-link" href="'.$_SESSION['url'].'petugas/table/table-akun-petugas.php"> <i class="fas fa-street-view"></i> Table Akun Petugas</a>
			  	    	<a class="nav-item nav-link" href="'.$_SESSION['url'].'petugas/table/table-daftar-permintaan-perbaikan.php"> <i class="fas fa-list-ol"></i> Table Daftar Permintaan Perbaikan</a>
			 	   </div>
				 </div>
			</nav>


			<nav class="navbar navbar-expand-xs navbar-dark navbar-dashboard">
			 	<a class="navbar-brand" href="#"><i class="fas fa-chart-bar"></i> Data Presentation </a>
			 <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar4" aria-controls="navbar4" aria-expanded="false" aria-label="Toggle navigation">
			    <span class="fas fa-angle-down"></span>
			 </button>
				 <div class="collapse navbar-collapse" id="navbar4">
			    	<div class="navbar-nav">
			   	   		<a class="nav-item nav-link" href="'.$_SESSION['url'].'petugas/data-presentation/grafik-perbulan.php"> <i class="fas fa-file-contract"></i> Grafik Laporan/bulan<span class="sr-only">(current)</span></a>
			 	   </div>
				 </div>
			</nav>





			


			<nav class="navbar navbar-expand-xs navbar-dark navbar-dashboard mb-2 pb-2">
			 	<a class="navbar-brand" href="#"><i class="fas fa-user"></i> Accounts </a>
			 <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar6" aria-controls="navbar6" aria-expanded="false" aria-label="Toggle navigation">
			    <span class="fas fa-angle-down"></span>
			 </button>
				 <div class="collapse navbar-collapse" id="navbar6">
			    	<div class="navbar-nav">
			   	   		<a class="nav-item nav-link" href="'.$_SESSION['url'].'petugas/accounts/buat-akun-petugas.php"> <i class="fas fa-user-plus"></i> Buat Akun Petugas<span class="sr-only">(current)</span></a>
			 	   </div>
				 </div>
			</nav>


			

            

        
        </div>

        <div class="col-md-9 ml-auto">

        	<nav class="navbar navbar-expand-xs navbar-light bg-light">
				 <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
			    <span class="navbar-toggler-icon"></span>
			  </button>

			  <div class="text-center text-uppercase titleNav">' . $titleNav . '</div>

			  <div class="navbar-brand">'. Get::tanggalIni() .'</div>
			 
			  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
			    <div class="navbar-nav">
			      <a class="nav-item nav-link active ml-3" href="'.$_SESSION['url'].'backend/keluar.php?logout='.base64_encode($_SESSION['nama']).'"><i class="fas fa-sign-out-alt"></i> Log out account<span class="sr-only">(current)</span></a>
			    </div>
			  </div>
			</nav>
				<div class="container-fluid">


<div class="row justify-content-center mt-3 text-center">
	<div class="col-md-2 bg-success mr-4 shadow">

		<div class="content-child">
			<i class="fas fa-user-tie"></i>
			Total Petugas
			<div class="number">' . $_SESSION['totalPetugas'] . '</div>
		</div>

	</div>

	<div class="col-md-2 bg-primary mr-4 shadow">
		
		<div class="content-child">
			<i class="fas fa-toolbox"></i>
			Total Perbaikan
			<div class="number">'. $_SESSION['totalPerbaikan'] .'</div>
		</div>

		
	</div>

	<div class="col-md-2 bg-info mr-4 shadow">
		
		<div class="content-child">
			<i class="fas fa-envelope-square"></i>
			Total Laporan
			<div class="number">'.$_SESSION['total-laporan'] .'</div>
		</div>
		
	</div>

	<div class="col-md-2 bg-danger mr-4 shadow">
		
		<div class="content-child">
			<i class="fas fa-hammer"></i>
			Total Dikerjakan
			<div class="number">'. $_SESSION['totalDikerjakan'] .'</div>
		</div>
		
	</div>

	<div class="col-md-2 bg-warning shadow">
		
		<div class="content-child">
			<i class="fas fa-ban"></i>
			Total Diabaikan
			<div class="number">' . $_SESSION['totalDiabaikan'] . '</div>
		</div>
		
	</div>

  </div>';

	}

	public static function dashFootPetugas(){

		echo '        	  </div>
						</div>
    
    
    				</div>
				</div>'	;
	}
}