<?php

	$server = 'localhost';
	$user   = 'root';
	$pass   = '';
	$db     = 'aplikasi-keluhan-kerusakan';

	$conn = new mysqli($server,$user,$pass,$db);

	$_SESSION['Koneksi'] = $conn;

	if ( $conn->connect_error )
		
	{
		echo 'Koneksi Gagal : '.$conn->connect_error;
	}


