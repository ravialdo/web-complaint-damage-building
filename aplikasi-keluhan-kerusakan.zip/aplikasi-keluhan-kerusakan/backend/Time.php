<?php

class Time{

	public static function timeAgo($waktu){

		date_default_timezone_set('Asia/Jakarta');

		$logic = array(
			array(60 * 60 * 24 * 365, 'tahun '),
			array(60 * 60 * 24 * 30, 'bulan '),
			array(60 * 60 * 24 * 7, 'minggu '),
			array(60 * 60 * 24, 'hari '),
			array(60 * 60, 'jam '),
			array(60, 'menit '),
		);

		$today = time();

		$sejak = $today - $waktu;

		if( $sejak > 604800 ){

			$print = date('M jS', $waktu);

			if( $sejak > 31536000 ){

				$print  = date('Y', $waktu);

			}

			return $print;

		}

		for ($i = 0, $j = count($logic); $i < $j ; $i++) { 
				
				$seconds = $logic[$i][0];
				$name = $logic[$i][1];

				if(($count = floor($sejak / $seconds )) != 0 )

					break;

		}

		$print = ($count == 1 ) ? '1 '. $name : "$count {$name}";

		if( $count == 0){

			$print = 'baru saja';
			return $print;
			break;
		}
		return $print . 'yang lalu';

	}

}