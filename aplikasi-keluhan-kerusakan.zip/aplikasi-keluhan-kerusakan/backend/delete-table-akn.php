<?php 
require 'koneksi.php';

if( isset($_GET['akn']) ){

		$index = $_GET['akn'];

		$sql = "DELETE FROM akun WHERE akun . id = $index";

		$query = $conn->query($sql);

	}if( $query == true ){

		header('location: http://localhost/aplikasi-keluhan-kerusakan/petugas/table/table-akun-petugas.php');

	}

 ?>