<?php

require 'koneksi.php';

$sqllihatAkunMahasiswa = "SELECT * FROM akun WHERE level = 'mahasiswa'";

$queryLihatAkunMahasiswa = $conn->query($sqllihatAkunMahasiswa);