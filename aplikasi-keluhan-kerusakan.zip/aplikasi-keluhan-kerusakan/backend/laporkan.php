<?php
date_default_timezone_set('Asia/Jakarta');
require 'koneksi.php';
require 'validasi-login.php';
require 'Get.php';

if( isset($_POST['lapor']) ){

	$namafileLokasi     = $_FILES['lokasi']['name'];
	$ukuranFileLokasi   = $_FILES['lokasi']['size'];
	$fileErrorLokasi    = $_FILES['lokasi']['error'];
	$tipeLokasi         = $_FILES['lokasi']['type'];
	$folderLokasi       = $_FILES['lokasi']['tmp_name'];
	$pindahLokasi       = '../assets/img/'.$namafileLokasi;

	$namafileProfile     = $_FILES['profile']['name'];
	$ukuranFileProfile   = $_FILES['profile']['size'];
	$fileErrorProfile    = $_FILES['profile']['error'];
	$tipeProfile         = $_FILES['profile']['type'];
	$folderProfile       = $_FILES['profile']['tmp_name'];
	$pindahProfile       = '../assets/img/'.$namafileProfile;

	$nip          = $_POST['nip'];
	$nama         = $_POST['nama'];
	$keluhan      = $_POST['keluhan'];
	$fasilitas    = $_POST['fasilitas'];
	$keterangan   = $_POST['keterangan'];
	$tanggalLapor = Get::tanggal();
	$bulan        = Get::bulan();
	$tahun        = Get::tahun();
	$waktu 		  = Get::waktu();
	


	if( $tipeLokasi == 'image/jpeg' || $tipeLokasi == 'image/png' && $tipeProfile == 'image/jpeg' || $tipeProfile == 'image/png' ){

		if( $ukuranFileLokasi <= 2000000 && $ukuranFileProfile <= 2000000 ){

			if( move_uploaded_file($folderLokasi, $pindahLokasi) && move_uploaded_file($folderProfile, $pindahProfile) ){

				$sqlLaporkan = "INSERT INTO data_keluhan (nama_mahasiswa, nama_keluhan, fasilitas, tanggal_lapor, waktu, tanda_pelapor, foto_lokasi, keterangan, bulan, tahun, status_perbaikan)
				VALUES ('$nama', '$keluhan', '$fasilitas', '$tanggalLapor', '$waktu', '$namafileProfile', '$namafileLokasi', '$keterangan', '$bulan', '$tahun', 'false')";
echo $sqlLaporkan;

							$queryLaporkan = $conn->query($sqlLaporkan);

							if( $queryLaporkan == true ){
								echo "data berhasil dimasukan";
								header('location: http://localhost/aplikasi-keluhan-kerusakan/');
							}else{
								echo "data gagal dimasukan";
								header('location: http://localhost/aplikasi-keluhan-kerusakan/mahasiswa/lapor/laporkan.php');	
							}
			}else{
				echo "pindah gagal";
			}
		}else{
				echo "ukuran terlalu besar";
		  }
	}else{
				echo "nama file tidak di dukung";
			}
}