<?php
date_default_timezone_set('Asia/Jakarta');
class Get {

	public static function waktu(){

		return date('H:i:s');
		
	}

	public static function tanggal(){

		return date('Y-m-d');

	}

	public static function bulan(){

		return date('M');
	}

	public static function tahun(){

		return date('Y');
	}

	public function tanggalIni(){

		$date = date('D');

		$dateIni = '';

		if( $date == 'Sun' ){

			$dateIni = 'Minggu';

		}else if( $date == 'Mon' ){

			$dateIni = 'Senin';

		}else if( $date == 'Tue' ){

			$dateIni = 'Selasa';
			
		}else if( $date == 'Wed' ){

			$dateIni = 'Rabu';
			
		}else if( $date == 'Thu' ){

			$dateIni = 'Kamis';
			
		}else if( $date == 'Fri' ){

			$dateIni = "Jum'at";
			
		}else if( $date == 'Sat' ){

			$dateIni = 'Sabtu';
			
		}

	return $dateIni.','.date('d M Y');
	}


}