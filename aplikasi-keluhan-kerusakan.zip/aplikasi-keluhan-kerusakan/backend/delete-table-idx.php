<?php 

require 'koneksi.php';

if( isset($_GET['idx']) ){

	$index = $_GET['idx'];

	$sql = "DELETE FROM daftar_permintaan_perbaikan WHERE daftar_permintaan_perbaikan . id = $index";

	$query = $conn->query($sql);

	if( $query == true ){

		header('location: http://localhost/aplikasi-keluhan-kerusakan/petugas/table/table-daftar-permintaan-perbaikan.php');

	}

}

 ?>