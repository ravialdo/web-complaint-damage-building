<?php

$sqlTrue = "SELECT * FROM data_keluhan WHERE status_perbaikan = 'true'";

$sedangDikerjakan = $conn->query($sqlTrue);

