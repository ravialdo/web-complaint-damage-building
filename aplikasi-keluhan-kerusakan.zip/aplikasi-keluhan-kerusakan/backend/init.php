<?php

require 'koneksi.php';

require 'belum-dikerjakan.php';
require 'sedang-dikerjakan.php';
require 'telah-selesai.php';
require 'total-petugas.php';
require 'total-mahasiswa.php';
require 'total-laporan.php';
require 'total-dikerjakan.php';
require 'total-perbaikan.php';
require 'daftar-diabaikan.php';
require 'total-diabaikan.php';
require 'Get.php';
require 'rincian.php';
require 'lihat-keluhan-masuk.php';
require 'lihat-akun-mahasiswa.php';
require 'lihat-akun-petugas.php';
require 'lihat-daftar-permintaan-perbaikan.php';
require 'grafik-laporan.php';
require 'lihat-laporan.php';
require 'Time.php';
require 'lihat-dikerjakan.php';

