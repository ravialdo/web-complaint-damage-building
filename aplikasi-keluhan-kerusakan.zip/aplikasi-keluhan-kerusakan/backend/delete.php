<?php

require 'koneksi.php';

if( isset($_GET['index']) ){

	$id = $_GET['index'];

	$sqldelete = "DELETE FROM data_keluhan WHERE id = $id";

	$queryDelete = $conn->query($sqldelete);

	if( $queryDelete == true ){

		header('location: http://localhost/aplikasi-keluhan-kerusakan/petugas/aktivitas/telah-selesai.php');
	}
}

 ?>