<?php



Class Grafik {

	public static function perbulan($bulan){

	require 'koneksi.php';

	$sqlGrafikLaporan = "SELECT * FROM data_keluhan WHERE bulan = '$bulan' AND tahun = '2019'";

	$queryGrafikLaporan = $conn->query($sqlGrafikLaporan);

	return $queryGrafikLaporan->num_rows;
	}

}


