<?php

require 'koneksi.php';

if( isset($_GET['detail']) ){

	$id = $_GET['detail'];

	$sqlDetail = "SELECT * FROM data_keluhan WHERE id = $id";

	$queryDetail = $conn->query($sqlDetail);

if($queryDetail == true ){

	header('location: http://localhost/aplikasi-keluhan-kerusakan/petugas/aktivitas/proses/rincian.php?dtl='.base64_encode($id));

  }

}
