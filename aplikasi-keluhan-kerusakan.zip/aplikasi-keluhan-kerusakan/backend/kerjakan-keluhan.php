<?php

require 'koneksi.php';
require 'Get.php';

if( isset($_POST['kirimPengerjaan']) ){

	$namaTeknisi = $_POST['namaTeknisi'];
	$estimasi    = $_POST['estimasi'];
	$id 		 = $_POST['id'];
	$delete		 = $_POST['delete'];
	$tanggal     = Get::tanggal();
	$waktu       = Get::waktu();

	$sqlPengerjaan = "UPDATE data_keluhan SET tanggal_mulai = '$tanggal', waktu_mulai = '$waktu', estimasi = '$estimasi', nama_teknisi = '$namaTeknisi', status_perbaikan = 'true' WHERE data_keluhan . id = $id";

	echo $sqlPengerjaan;

	$queryPengerjaan = $conn->query($sqlPengerjaan);

	if( $queryPengerjaan == true ){

			header('location: http://localhost/aplikasi-keluhan-kerusakan/petugas/aktivitas/belum-dikerjakan.php');

		}
	}else{

		header('location: http://localhost/aplikasi-keluhan-kerusakan/petugas/aktivitas/proses/pengerjaan.php');

	}