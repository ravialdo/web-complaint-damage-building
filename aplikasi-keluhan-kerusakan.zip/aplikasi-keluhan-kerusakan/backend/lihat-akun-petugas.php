<?php

require 'koneksi.php';

$sqllihatAkunPetugas = "SELECT * FROM akun WHERE level = 'petugas'";

$queryLihatAkunPetugas = $conn->query($sqllihatAkunPetugas);