<?php

require 'koneksi.php';

$sqllihatDPP = "SELECT * FROM daftar_permintaan_perbaikan";

$queryLihatDPP = $conn->query($sqllihatDPP);