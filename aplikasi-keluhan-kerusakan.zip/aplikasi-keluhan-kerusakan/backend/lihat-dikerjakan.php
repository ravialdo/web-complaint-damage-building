<?php

require 'koneksi.php';

$sqlLihatDikerjakan = "SELECT * FROM data_keluhan WHERE status_perbaikan = 'true'";

$queryLihatDataDikerjakan = $conn->query($sqlLihatDikerjakan);