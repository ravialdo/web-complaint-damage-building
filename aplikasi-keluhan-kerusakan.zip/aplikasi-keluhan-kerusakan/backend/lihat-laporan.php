<?php

require 'koneksi.php';

$sqlLihatData = "SELECT * FROM data_keluhan WHERE status_perbaikan = 'false'";

$queryLihatData = $conn->query($sqlLihatData);

