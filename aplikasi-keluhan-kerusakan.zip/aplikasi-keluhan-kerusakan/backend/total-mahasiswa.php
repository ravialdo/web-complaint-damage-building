<?php

$sqlTP = "SELECT * FROM akun WHERE level = 'mahasiswa'";

$queryTotalMahasiswa = $conn->query($sqlTP);


if( $queryTotalMahasiswa->num_rows > 0 ){

	$i = 0;

	while ( $queryTotalMahasiswa->fetch_assoc() ) {

		$i++;

	}

	$_SESSION['totalMahasiswa'] = $i;
	

}else {
	$_SESSION['totalMahasiswa'] = 0;
}