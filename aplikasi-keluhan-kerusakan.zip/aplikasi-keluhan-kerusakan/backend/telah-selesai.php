<?php

$sqlReady = "SELECT * FROM data_keluhan WHERE status_perbaikan = 'ready'";

$telahSelesai = $conn->query($sqlReady);
