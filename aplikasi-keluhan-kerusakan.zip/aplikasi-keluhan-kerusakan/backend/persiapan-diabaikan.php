<?php

require 'koneksi.php';

$id = $_GET['index'];

$sqlDiabaikan = "SELECT * FROM data_keluhan WHERE id = '$id'";

$queryDiabaikan = $conn->query($sqlDiabaikan);

unset($id);

$row = $queryDiabaikan->fetch_assoc();

		$delete 		= $row['id'];
		$namaMahasiswa	= $row['nama_mahasiswa'];
		$namaKeluhan	= $row['nama_keluhan'];
		$fasilitas		= $row['fasilitas'];
		$tanggalLapor 	= $row['tanggal_lapor'];
		$estimasi 		= $row['estimasi'];
		$tandaPelapor   = $row['tanda_pelapor'];
		$keterangan     = $row['keterangan'];

		$_SESSION['namaMahasiswa'] = $row['nama_mahasiswa'];;

		$Kerjakan = "INSERT INTO data_keluhan (nama_mahasiswa, nama_keluhan, fasilitas, estimasi, tanda_pelapor, keterangan, status_perbaikan)
					VALUES ('$namaMahasiswa','$namaKeluhan','$fasilitas','0000-00-00','$tandaPelapor','$keterangan','new')";


			$query = $conn->query($Kerjakan);

			$sql = "DELETE FROM data_keluhan WHERE data_keluhan . waktu = ''";

			$query = $conn->query($sql);
			

			if( $query == true ){
				header('location: http://localhost/aplikasi-keluhan-kerusakan/petugas/aktivitas/proses/pengerjaan-diabaikan.php?idx='.$delete.'&&nm='.$namaMahasiswa.'&&klh='.$namaKeluhan);
			}else {
				header('location: http://localhost/aplikasi-keluhan-kerusakan/petugas/aktivitas/diabaikan.php');

			}
