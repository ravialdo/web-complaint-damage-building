<?php

require 'koneksi.php';

	if( isset($_GET['klh']) ){

		$index = $_GET['klh'];

		$sql = "DELETE FROM data_keluhan WHERE data_keluhan . id = $index";

		$query = $conn->query($sql);

	}if( $query == true ){

		header('location: http://localhost/aplikasi-keluhan-kerusakan/petugas/table/table-keluhan-masuk.php');

	}