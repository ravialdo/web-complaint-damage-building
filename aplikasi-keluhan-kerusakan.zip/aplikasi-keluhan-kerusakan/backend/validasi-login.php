<?php
session_start();

require 'koneksi.php';

if (isset($_POST['login'])) {
	
	$username = $_POST['username'];
	$password = base64_encode($_POST['password']);

	$sqlLogin = "SELECT * FROM akun WHERE username = '$username' AND password = '$password'";

	$queryLogin = $conn->query($sqlLogin);

	if( $queryLogin->num_rows > 0 ){

	$row = $queryLogin->fetch_assoc();

	if( $row['level'] == 'petugas' ){

		$_SESSION['nama'] 		= $row['nama'];
		$_SESSION['username'] 	= $row['username'];
		$_SESSION['password']	= $row['password'];
		$_SESSION['profile'] 	= $row['profile'];
		$_SESSION['level'] 		= $row['level'];

		header('location: http://localhost/aplikasi-keluhan-kerusakan/petugas/');

	}else{

		header('location: http://localhost/aplikasi-keluhan-kerusakan/');

	}
}
}
