<?php

$sqlReady = "SELECT * FROM data_keluhan WHERE status_perbaikan = 'ready'";

$totalPerbaikan = $conn->query($sqlReady);

if ( $totalPerbaikan->num_rows > 0 ){

	$i = 0;

	while ( $totalPerbaikan->fetch_assoc()){

		$i++;

	}

	$_SESSION['totalPerbaikan'] = $i;

}else {
	$_SESSION['totalPerbaikan'] = 0;
}