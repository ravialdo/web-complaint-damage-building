<?php

$sqlNew = "SELECT * FROM data_keluhan WHERE status_perbaikan = 'new'";

$queryDiabaikan = $conn->query($sqlNew);