<?php

require 'koneksi.php';

$sqllihatKeluhanMasuk = "SELECT * FROM data_keluhan WHERE status_perbaikan = 'false'";

$queryLihatKeluhanMasuk = $conn->query($sqllihatKeluhanMasuk);