<?php

$sqlLihat = "SELECT * FROM data_keluhan WHERE status_perbaikan = 'false'";

$sqlLihat = $conn->query($sqlLihat);

if ( $sqlLihat->num_rows > 0){

	$i = 0;

	while ( $sqlLihat->fetch_assoc()){

		$i++;

	}

	$_SESSION['total-laporan'] = $i;

}else {
	$_SESSION['total-laporan'] = 0;
}