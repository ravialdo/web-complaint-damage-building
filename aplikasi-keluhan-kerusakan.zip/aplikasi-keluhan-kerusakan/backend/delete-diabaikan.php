<?php

require 'koneksi.php';

$id = $_GET['delete'];

$sqlDelete = "DELETE FROM data_keluhan WHERE id = '$id'";

$query = $conn->query($sqlDelete);

if( $query == true ){

	header('location: http://localhost/aplikasi-keluhan-kerusakan/petugas/aktivitas/diabaikan.php');

}
