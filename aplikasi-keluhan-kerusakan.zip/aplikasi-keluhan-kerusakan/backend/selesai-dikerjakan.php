<?php

require 'koneksi.php';
require 'Get.php';

if( isset($_GET['finish']) ){

	$id = $_GET['finish'];

	$tanggalSelesai  = Get::Tanggal();
	$waktu           = Get::waktu();


	$sqlFinish = "UPDATE data_keluhan SET tanggal_selesai = '$tanggalSelesai', waktu_selesai = '$waktu', status_perbaikan = 'ready' WHERE id = $id";

	$queryFinish = $conn->query($sqlFinish);

	if( $queryFinish == true ){

		$sql = "SELECT * FROM data_keluhan WHERE id = $id";

		$query = $conn->query($sql);

		$row = $query->fetch_assoc();

		$id 			 = $row['id'];
		$namaMahasiswa   = $row['nama_mahasiswa'];
		$keluhan    	 = $row['nama_keluhan'];
		$fasilitas 		 = $row['fasilitas'];
		$tanggalLapor    = $row['tanggal_lapor'];
		$tanggalMulai	 = $row['tanggal_mulai'];
		$tanggalSelesai  = $row['tanggal_selesai'];
		$estimasi		 = $row['estimasi'];
		$namaTeknisi     = $row['nama_teknisi'];
		$tandaPelapor    = $row['tanda_pelapor'];
		$fotoLokasi      = $row['foto_lokasi'];
		$keterangan      = $row['keterangan'];
		$statusPerbaikan = $row['status_perbaikan'];
		

		

		$sqlToTable = "INSERT INTO daftar_permintaan_perbaikan (pelapor, nama_perbaikan, fasilitas, dikerjakan, tanggal, nama_teknisi, tanggal_lapor, tanggal_selesai, estimasi, tanda_pelapor, keterangan)
			VALUES ('$namaMahasiswa', '$keluhan', '$fasilitas', 'selesai', '$tanggalMulai', '$namaTeknisi', '$tanggalLapor', '$tanggalSelesai', '$estimasi', '$tandaPelapor', '$keterangan')";

			
			
			 $queryToTable = $conn->query($sqlToTable);

			if( $queryToTable == true ){

				header('location: http://localhost/aplikasi-keluhan-kerusakan/petugas/aktivitas/telah-selesai.php');

			}

		

	}else {

		 header('location: http://localhost/aplikasi-keluhan-kerusakan/petugas/aktivitas/sedang-dikerjakan.php');

	}
}