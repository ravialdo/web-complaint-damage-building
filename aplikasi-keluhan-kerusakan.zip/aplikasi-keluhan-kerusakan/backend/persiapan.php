<?php

require 'koneksi.php';
require 'Get.php';

$id = $_GET['index'];

$sqlKerjakan = "SELECT * FROM data_keluhan WHERE id = '$id'";

$queryKerjakan = $conn->query($sqlKerjakan);

unset($id);

$row = $queryKerjakan->fetch_assoc();

		$delete 		= $row['id'];
		$namaMahasiswa	= $row['nama_mahasiswa'];
		$namaKeluhan	= $row['nama_keluhan'];
		$fasilitas		= $row['fasilitas'];
		$tanggalLapor 	= $row['tanggal_lapor'];
		$waktuLapor     = $row['waktu'];
		$tanggalMulai   = Get::tanggal();
		$estimasi 		= $row['estimasi'];
		$tandaPelapor   = $row['tanda_pelapor'];
		$fotoLokasi 	= $row['foto_lokasi'];
		$keterangan     = $row['keterangan'];
		$bulan   		= $row['bulan'];
		$tahun          = $row['tahun'];


		$_SESSION['namaMahasiswa'] = $row['nama_mahasiswa'];

		$Kerjakan = "INSERT INTO data_keluhan (nama_mahasiswa, nama_keluhan, fasilitas, tanggal_lapor, waktu,  tanggal_mulai, tanda_pelapor, foto_lokasi, keterangan, bulan, tahun, status_perbaikan)
					VALUES ('$namaMahasiswa','$namaKeluhan','$fasilitas','$tanggalLapor', '$waktuLapor','$tanggalMulai','$tandaPelapor','$fotoLokasi','$keterangan', '$bulan', '$tahun','new')";
					echo $Kerjakan;
			$query = $conn->query($Kerjakan);

			var_dump($query);
			


			if( $query == true ){
				header('location: http://localhost/aplikasi-keluhan-kerusakan/petugas/aktivitas/proses/pengerjaan.php?idx='.base64_encode($delete).'&&nm='.base64_encode($namaMahasiswa).'&&klh='.base64_encode($namaKeluhan).'&&tg='.base64_encode($tanggalLapor));
			}else {
				#header('location: http://localhost/aplikasi-keluhan-kerusakan/petugas/aktivitas/belum-dikerjakan.php');

			}
