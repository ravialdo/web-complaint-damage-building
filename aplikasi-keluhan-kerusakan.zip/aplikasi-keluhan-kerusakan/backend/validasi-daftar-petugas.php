<?php

require 'koneksi.php';

if( isset($_POST['daftarPetugas']) ){

	$namaFile = $_FILES['gambar']['name'];
	$ukuranFile = $_FILES['gambar']['size'];
	$fileError = $_FILES['gambar']['error'];
	$tipe = $_FILES['gambar']['type'];
	$nama = $_POST['nama'];
	$username = $_POST['username'];
	$password = $_POST['password'];
	$folder = $_FILES['gambar']['tmp_name'];
	$pindah = '../assets/img/'.$namaFile;

	echo $tipe;

	if( $tipe == 'image/jpeg' || $tipe == 'image/png' ){

		if( $ukuranFile <= 1000000 ){

			if( $uploaded = move_uploaded_file($folder, $pindah) ){

					$sqlUpload = "INSERT INTO akun (nama, username, password, profile, level)
								  VALUES ('$nama','$username','".base64_encode($password)."','$namaFile','petugas')";

								  echo $sqlUpload;

					$queryUpload = $conn->query($sqlUpload);

					if($queryUpload == true){

						header('location: http://localhost/aplikasi-keluhan-kerusakan/petugas/');

					}else{

						header('location: http://localhost/aplikasi-keluhan-kerusakan/petugas/accounts/buat-akun-petugas.php');

					}

			}

		}

	}

}