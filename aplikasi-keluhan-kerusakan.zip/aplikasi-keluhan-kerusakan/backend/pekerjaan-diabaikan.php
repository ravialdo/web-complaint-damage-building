<?php

require 'koneksi.php';

if ( isset($_GET['later']) ){
	
	$id = $_GET['later'];

	$sqlAbaikan = "UPDATE data_keluhan  SET status_perbaikan  = 'new' WHERE data_keluhan . id  = $id";

	$queryAbaikan = $conn->query($sqlAbaikan);

	if ( $queryAbaikan == true ) {
		
		header('location: http://localhost/aplikasi-keluhan-kerusakan/petugas/aktivitas/diabaikan.php');

	}else {

		header('location: http://localhost/aplikasi-keluhan-kerusakan/petugas/aktivitas/belum-dikerjakan.php');

	}
}

