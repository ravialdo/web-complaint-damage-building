<?php

$sqlFalse = "SELECT * FROM data_keluhan WHERE status_perbaikan = 'false'";

$belumDikerjakan = $conn->query($sqlFalse);
