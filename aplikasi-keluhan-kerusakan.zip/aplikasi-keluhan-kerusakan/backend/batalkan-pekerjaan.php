<?php

require 'koneksi.php';

if ( isset($_GET['cancel']) ) {
	
	$id = $_GET['cancel'];

		$sqlCancel = "UPDATE  data_keluhan  SET  status_perbaikan  = 'false' WHERE  data_keluhan . id  = $id";

		$queryCancel = $conn->query($sqlCancel);

		if( $queryCancel == true ){

			header('location: http://localhost/aplikasi-keluhan-kerusakan/petugas/aktivitas/belum-dikerjakan.php');

		}else {

			header('location: http://localhost/aplikasi-keluhan-kerusakan/petugas/aktivitas/sedang-dikerjakan.php');
		}

}
