<?php

session_start();

if( isset($_GET['logout']) ){

session_unset($_SESSION['nama']);
session_unset($_SESSION['username']);
session_unset($_SESSION['password']);
session_unset($_SESSION['profile']);
session_unset($_SESSION['level']);


header('location: http://localhost/aplikasi-keluhan-kerusakan/');

}