<?php

$sqlTP = "SELECT * FROM akun WHERE level = 'petugas'";

$queryTotalPetugas = $conn->query($sqlTP);

if( $queryTotalPetugas->num_rows > 0 ){

	$i = 0;

	while ( $queryTotalPetugas->fetch_assoc() ) {

		$i++;

	}

	$_SESSION['totalPetugas'] = $i;

}else {
	$_SESSION['totalPetugas'] = 0;
}
