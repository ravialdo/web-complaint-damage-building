<?php

require 'koneksi.php';
require 'Get.php';

if( isset($_POST['kirimPengerjaanDiabaikan']) ){

	$namaTeknisi  = $_POST['namaTeknisi'];
	$estimasi     = $_POST['estimasi'];
	$id 		  = $_POST['id'];
	$tanggalMulai = Get::tanggal();
	$delete		  = $_POST['delete'] + 1;
	$waktu 		  =  Get::waktu();

	$sqlPengerjaan = "UPDATE data_keluhan SET tanggal_mulai = '$tanggalMulai', waktu_mulai = '$waktu', estimasi = '$estimasi', nama_teknisi = '$namaTeknisi', status_perbaikan = 'true' WHERE data_keluhan . id = $id";

	echo $sqlPengerjaan;

	$queryPengerjaan = $conn->query($sqlPengerjaan);

	$sqlDelete = "DELETE FROM data_keluhan WHERE data_keluhan . id = $delete";

	$conn->query($sqlDelete);


	if( $queryPengerjaan == true ){


			header('location: http://localhost/aplikasi-keluhan-kerusakan/petugas/aktivitas/diabaikan.php');

		}

	}else{

		header('location: http://localhost/aplikasi-keluhan-kerusakan/petugas/aktivitas/proses/pengerjaan.php');

	}

