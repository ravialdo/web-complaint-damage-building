<?php

$sqlDiabaikan = "SELECT * FROM data_keluhan WHERE status_perbaikan = 'new'";

$totalDiabaikan = $conn->query($sqlDiabaikan);

if ( $totalDiabaikan->num_rows > 0){

	$i = 0;

	while ( $totalDiabaikan->fetch_assoc()){

		$i++;

	}

	$_SESSION['totalDiabaikan'] = $i;

}else{

	$_SESSION['totalDiabaikan'] = 0;

}