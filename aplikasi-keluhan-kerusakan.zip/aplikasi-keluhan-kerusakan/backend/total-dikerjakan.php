<?php

$sqlTrue = "SELECT * FROM data_keluhan WHERE status_perbaikan = 'true'";

$totalDikerjakan = $conn->query($sqlTrue);

if ( $totalDikerjakan->num_rows > 0){

	$i = 0;

	while ( $totalDikerjakan->fetch_assoc()){

		$i++;

	}

	$_SESSION['totalDikerjakan'] = $i;

}else {
	$_SESSION['totalDikerjakan'] = 0;
}