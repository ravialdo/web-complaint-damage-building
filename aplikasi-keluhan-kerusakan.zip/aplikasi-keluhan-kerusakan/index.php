<?php

require 'Template/init.php';
require 'backend/init.php';

Header::head('Selamat Datang!');

?>


<div class="container-fluid" style="
	background-image: url('assets/img/landing.jpg');
 	height: 600px;
 	background-size: cover;
	background-repeat: no-repeat;
	background-attachment: fixed;
	height: -webkit-fill-available;
	">


	<div class="row">
           
		<div class="col-md-12 text-center">

			<a href="<?=$_SESSION['url']?>login.php" class="btn btn-warning float-right mt-3 mr-3" role="button">Login Petugas!</a>

			<div class="display-3" style="font-size: 50px; font-weight: bold; margin-top: 20%;">
				Telkom <span style=" color: #cc1022!important;">University</span>
				<div class="h1 text-dark">Laporkan keluhan anda, demi kenyamanan anda!</div>
				<a href="<?=$_SESSION['url']?>mahasiswa/lapor/laporkan.php" class="btn btn-primary" role="button">Laporkan</a>
				<a href="<?=$_SESSION['url']?>mahasiswa/lihat/lihat-laporan.php" class="btn btn-success" role="button">Lihat Laporan</a>
				
			</div>
		</div>
	</div>

	
	


</div>


<?php

Dashboard::dashFootPetugas();

Footer::foot();

?>