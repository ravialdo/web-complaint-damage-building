-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 15, 2019 at 08:58 AM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 5.6.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aplikasi-keluhan-kerusakan`
--

-- --------------------------------------------------------

--
-- Table structure for table `akun`
--

CREATE TABLE `akun` (
  `id` int(11) NOT NULL,
  `nama` char(20) NOT NULL,
  `username` char(20) NOT NULL,
  `password` varchar(225) NOT NULL,
  `profile` varchar(225) NOT NULL DEFAULT 'profile.jpg',
  `level` char(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `akun`
--

INSERT INTO `akun` (`id`, `nama`, `username`, `password`, `profile`, `level`) VALUES
(16, 'Nickname', 'petugas', 'cGV0dWdhczEyMw==', '4wG1I8jU2DXMeu-7PylPDPWCyZ4FgoKMshrCQJWaXHZbr3Fr4_wMPQWU1EPjKqhSTLHNmTjlbk-1MaoMU1rzbuY4kFyhOT7p=w200-h200-nc.png', 'petugas');

-- --------------------------------------------------------

--
-- Table structure for table `daftar_permintaan_perbaikan`
--

CREATE TABLE `daftar_permintaan_perbaikan` (
  `id` int(11) NOT NULL,
  `pelapor` char(100) NOT NULL,
  `nama_perbaikan` char(50) NOT NULL,
  `fasilitas` char(100) NOT NULL,
  `dikerjakan` varchar(10) NOT NULL DEFAULT '-' COMMENT 'status perbaikan',
  `tanggal` date NOT NULL COMMENT 'status perbaikan',
  `nama_teknisi` char(50) NOT NULL,
  `tanggal_lapor` date NOT NULL,
  `tanggal_selesai` date NOT NULL,
  `estimasi` date NOT NULL,
  `tanda_pelapor` varchar(50) NOT NULL,
  `keterangan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `data_keluhan`
--

CREATE TABLE `data_keluhan` (
  `id` int(11) NOT NULL,
  `nama_mahasiswa` char(50) NOT NULL,
  `nama_keluhan` char(100) NOT NULL,
  `fasilitas` char(50) NOT NULL,
  `tanggal_lapor` date NOT NULL,
  `waktu` varchar(8) NOT NULL,
  `tanggal_mulai` date NOT NULL,
  `waktu_mulai` varchar(8) NOT NULL,
  `tanggal_selesai` date NOT NULL,
  `waktu_selesai` varchar(8) NOT NULL,
  `estimasi` date NOT NULL,
  `nama_teknisi` char(50) NOT NULL,
  `tanda_pelapor` varchar(225) NOT NULL,
  `foto_lokasi` varchar(50) NOT NULL,
  `keterangan` text NOT NULL,
  `bulan` char(10) NOT NULL COMMENT 'kategori',
  `tahun` int(11) NOT NULL COMMENT 'kategori',
  `status_perbaikan` char(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_keluhan`
--

INSERT INTO `data_keluhan` (`id`, `nama_mahasiswa`, `nama_keluhan`, `fasilitas`, `tanggal_lapor`, `waktu`, `tanggal_mulai`, `waktu_mulai`, `tanggal_selesai`, `waktu_selesai`, `estimasi`, `nama_teknisi`, `tanda_pelapor`, `foto_lokasi`, `keterangan`, `bulan`, `tahun`, `status_perbaikan`) VALUES
(11, 'Ravialdo', 'Dinding', 'Gedung', '2019-01-15', '14:31:45', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '4wG1I8jU2DXMeu-7PylPDPWCyZ4FgoKMshrCQJWaXHZbr3Fr4_wMPQWU1EPjKqhSTLHNmTjlbk-1MaoMU1rzbuY4kFyhOT7p=w200-h200-nc.png', 'IMG-20190102-WA0000.jpg', 'Tolong segera di perbaiki!', 'Jan', 2019, 'false'),
(12, 'Robby', 'Kaca', 'Gedung', '2019-01-15', '14:33:03', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', 'no-profile-image-png.png', 'IMG-20190102-WA0000.jpg', 'Kaca pecah tolong segera diperbaiki!', 'Jan', 2019, 'false'),
(13, 'Idan', 'Lantai', 'Gedung', '2019-01-15', '14:34:31', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '4wG1I8jU2DXMeu-7PylPDPWCyZ4FgoKMshrCQJWaXHZbr3Fr4_wMPQWU1EPjKqhSTLHNmTjlbk-1MaoMU1rzbuY4kFyhOT7p=w200-h200-nc.png', 'IMG-20190102-WA0000.jpg', 'Lantai mulai retak dan kotor!', 'Jan', 2019, 'false'),
(14, 'Yopi', 'Toilet,kran', 'Umum', '2019-01-15', '14:36:10', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '4wG1I8jU2DXMeu-7PylPDPWCyZ4FgoKMshrCQJWaXHZbr3Fr4_wMPQWU1EPjKqhSTLHNmTjlbk-1MaoMU1rzbuY4kFyhOT7p=w200-h200-nc.png', 'IMG-20190102-WA0000.jpg', 'Toilet kotor dan kran tidak mau menyala!', 'Jan', 2019, 'false'),
(15, 'Rai', 'Genting', 'Gedung', '2019-01-15', '14:39:06', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', 'no-profile-image-png.png', 'IMG-20190102-WA0000.jpg', 'Genting telah mulai bocor!', 'Jan', 2019, 'false'),
(16, 'Ravialdo', 'Komputer', 'Kantor', '2019-01-15', '14:41:44', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '4wG1I8jU2DXMeu-7PylPDPWCyZ4FgoKMshrCQJWaXHZbr3Fr4_wMPQWU1EPjKqhSTLHNmTjlbk-1MaoMU1rzbuY4kFyhOT7p=w200-h200-nc.png', 'IMG-20190102-WA0000.jpg', 'Komputer rusak/mati total!', 'Jan', 2019, 'false'),
(17, 'Robby', 'Kursi', 'Kantor', '2019-01-15', '14:43:53', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', 'no-profile-image-png.png', 'IMG-20190102-WA0000.jpg', 'kursi telah rusak tolong diperbaiki!', 'Jan', 2019, 'false'),
(18, 'Yopi', 'Meja', 'Ruangan kelas', '2019-01-15', '14:46:37', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '4wG1I8jU2DXMeu-7PylPDPWCyZ4FgoKMshrCQJWaXHZbr3Fr4_wMPQWU1EPjKqhSTLHNmTjlbk-1MaoMU1rzbuY4kFyhOT7p=w200-h200-nc.png', 'no-profile-image-png.png', 'Meja patah segera perbaiki!', 'Jan', 2019, 'false'),
(19, 'Idan', 'CCTV', 'Gedung', '2019-01-15', '14:49:22', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', 'no-profile-image-png.png', 'IMG-20190102-WA0000.jpg', 'CCTV mati tolong di perbaiki!', 'Jan', 2019, 'false'),
(20, 'Rai', 'AC', 'Gedung', '2019-01-15', '14:52:09', '0000-00-00', '', '0000-00-00', '', '0000-00-00', '', '4wG1I8jU2DXMeu-7PylPDPWCyZ4FgoKMshrCQJWaXHZbr3Fr4_wMPQWU1EPjKqhSTLHNmTjlbk-1MaoMU1rzbuY4kFyhOT7p=w200-h200-nc.png', 'IMG-20190102-WA0000.jpg', 'AC telah rusak segera diperbaiki!', 'Jan', 2019, 'false');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `akun`
--
ALTER TABLE `akun`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `password` (`password`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `daftar_permintaan_perbaikan`
--
ALTER TABLE `daftar_permintaan_perbaikan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data_keluhan`
--
ALTER TABLE `data_keluhan`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `akun`
--
ALTER TABLE `akun`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `daftar_permintaan_perbaikan`
--
ALTER TABLE `daftar_permintaan_perbaikan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `data_keluhan`
--
ALTER TABLE `data_keluhan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
